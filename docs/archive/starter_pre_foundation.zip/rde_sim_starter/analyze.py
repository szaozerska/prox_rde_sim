"""Post-process a run (plan D32-D42, plus roll stability).

usage: python analyze.py run_name
Writes <run>_results.json, <run>_summary.md, <run>_waves.png
"""
import json, math, sys
import numpy as np
import yaml
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = sys.path[0]
run = sys.argv[1]
d = np.load(f"{HERE}/{run}.npz")
meta = json.load(open(f"{HERE}/{run}.json"))
c = json.load(open(f"{HERE}/{meta.get('calib', 'calib')}.json"))
cfg = yaml.safe_load(open(f"{HERE}/config.yaml"))
op = cfg["operating_point"]
g, R, q = c["gamma"], c["R"], c["q"]
Wd, ro, rm, gap = meta["Wd"], meta["ro"], meta["rm"], meta["gap"]
G0 = 9.80665

t = d["t"]; dt = d["dt"]
t0 = meta["t_avg0"] if t[-1] > meta["t_avg0"] + 0.2e-3 else 0.4 * t[-1]
win = t >= t0
wavg = lambda a: float((a[win] * dt[win]).sum() / dt[win].sum())

# ---------------- D32: x-t diagram and 2D FFT ----------------
ptx = d["probe_p"][win].astype(np.float64)
tw = t[win]
nt = len(tw)
tu = np.linspace(tw[0], tw[-1], nt)                     # resample onto a uniform clock
ptx = np.array([np.interp(tu, tw, ptx[:, i]) for i in range(ptx.shape[1])]).T
dtu = tu[1] - tu[0]
sig = (ptx - ptx.mean()) * np.hanning(nt)[:, None]        # Hanning window in time (Mundt p. 43)
P = np.abs(np.fft.fft2(sig)) ** 2
fr = np.fft.fftfreq(nt, dtu)                              # Hz
kk = np.fft.fftfreq(ptx.shape[1], 1.0 / ptx.shape[1])     # integer wave number around the ring
fmin = 2e3
pos = fr > fmin
Pp = P[pos]; frp = fr[pos]
# numpy convention: a wave moving in +x appears at (f > 0, k < 0)
i_f, i_k = np.unravel_index(np.argmax(Pp[:, kk != 0] if False else np.where(kk[None, :] != 0, Pp, 0)), Pp.shape)
f0 = frp[i_f]; k0 = int(kk[i_k])
N = abs(k0)
direction = "+x" if k0 < 0 else "-x"
P0 = Pp[i_f, i_k]
ic = np.where(kk == -k0)[0][0]
Pc = Pp[:, ic].max()                                      # counter wave: same N, opposite direction
P_pulse = Pp[:, kk == 0].max()                            # longitudinal pulsing (k = 0)
cw_ratio = float(Pc / P0)

# steadiness: dominant (N, f) in three sub-windows (Mundt spectrogram check, Figs. 3.7/3.9)
subs = []
for part in np.array_split(np.arange(nt), 3):
    s_ = (ptx[part] - ptx[part].mean()) * np.hanning(len(part))[:, None]
    Ps = np.abs(np.fft.fft2(s_)) ** 2
    frs = np.fft.fftfreq(len(part), dtu)
    Pps = np.where((frs[:, None] > fmin) & (kk[None, :] != 0), Ps, 0)
    a_, b_ = np.unravel_index(np.argmax(Pps), Ps.shape)
    subs.append((abs(int(kk[b_])), float(frs[a_])))
steady = len({s_[0] for s_ in subs}) == 1 and (max(s_[1] for s_ in subs) / min(s_[1] for s_ in subs) - 1) < 0.10
# (+-5% target from the plan; a 3-way split of a short window has ~3-5% frequency resolution,
#  so 10% spread is used as the practical threshold here)

D_sim = f0 * Wd / max(N, 1)                    # D35: on the simulated (mean) circumference
D_mundt = f0 * 2 * math.pi * ro / max(N, 1)    # Mundt's outer-circumference convention
pk_ratio = float(ptx.max(axis=1).mean() / ptx.mean())
detonative = (N > 0) and (D_sim / c["D_CJ"] > 0.4) and (pk_ratio > 5) and (P0 > P_pulse)

if not detonative:
    mode = "longitudinal pulsing" if P_pulse >= P0 else "deflagration / no sustained detonation"
elif not steady:
    mode = "unsteady / chaotic"
elif cw_ratio < 0.05:
    mode = f"{N}-wave, no counter wave"
elif cw_ratio < 0.58:
    mode = f"{N}-wave + weak counter wave"
else:
    mode = f"{N}-wave + strong counter wave"

# ---------------- D38/D40: wave-frame Mach and fill height from snapshots ----------------
S = d["snaps"]; jp = meta["jp"]
M1s, M2s, hs = [], [], []
sgn = 1 if direction == "+x" else -1
dxg = meta["dx"]
for sn in S:
    p_, T_, xi_, M_, u_, v_ = sn
    row = p_[:, jp]
    iw = int(np.argmax(row))                               # strongest wave front at the probe row
    nx = row.size
    ahead = [(iw + sgn * m) % nx for m in range(3, 12)]
    rho_a = p_[ahead, jp] / (R * T_[ahead, jp])
    a_fill = np.sqrt(g * p_[ahead, jp] / rho_a).mean()
    M1s.append((D_sim - sgn * u_[ahead, jp].mean()) / a_fill)
    # behind the front: first cell where the reaction is ~complete
    for m in range(1, 60):
        ib = (iw - sgn * m) % nx
        if xi_[ib, jp] > 0.95:
            a_b = math.sqrt(g * p_[ib, jp] * R * T_[ib, jp] / p_[ib, jp])
            M2s.append(abs(D_sim - sgn * u_[ib, jp]) / a_b)
            break
    col = (iw + sgn * int(2e-3 / dxg)) % nx                # 2 mm ahead of the front
    fresh = xi_[col] < 0.5
    h_cells = np.argmin(fresh) if not fresh.all() else fresh.size
    hs.append(h_cells * meta["dy"])

# ---------------- D39: axial pressure profile vs Table 3-2 ----------------
y = d["y"]; prof = d["prof_p"]
z_paper = np.array([0.0, 22.2, 34.9, 47.6, 60.3, 73.0]) * 1e-3
p_paper = np.array([368.5, 323.3, 292.3, 281.1, 255.4, 238.4]) * 1e3
p_sim = np.interp(z_paper, y, prof)
p65 = np.interp(0.65 * meta["L"], y, prof)

# ---------------- D36/D37: thrust, torque, mass balance ----------------
mdot_in, mdot_out = wavg(d["mdot_in"]), wavg(d["mdot_out"])
F_exit, F_bot = wavg(d["F_exit"]), wavg(d["F_bottom"])
tau_gas = wavg(d["tau_gas"])
tau_eng = -tau_gas
tau_series = -d["tau_gas"][win]
u_exit = wavg(d["u_exit"]); M_exit = wavg(d["M_exit"])
Isp = F_exit / (mdot_in * G0)
swirl_power_frac = abs(mdot_out * D_sim * u_exit) / (mdot_in * q)    # Mundt Eq. 4.7 / Fig. 4.28
tau_fluct = float(tau_series.std() / max(abs(tau_eng), 1e-12))

res = dict(
    run=run, grid=dict(dx_mm=meta["dx"] * 1e3, nx=meta["nx"], ny=meta["ny"]),
    chemistry=dict(L_half_mm=c["L_half"] * 1e3, Ea_over_RT1=c.get("Ea_over_RT1")),
    window_ms=[float(t0 * 1e3), float(t[-1] * 1e3)],
    wave_stability=dict(mode=mode, detonative=bool(detonative), N=N, direction=direction,
                        f_kHz=f0 / 1e3, steady=bool(steady), subwindows=subs,
                        counter_wave_power_ratio=cw_ratio, pulsing_power_ratio=float(P_pulse / P0),
                        D_sim=D_sim, D_mundt_convention=D_mundt, D_over_DCJ=D_sim / c["D_CJ"],
                        peak_to_mean_p=pk_ratio),
    mach=dict(M1_wave_frame=float(np.mean(M1s)) if M1s else None, M_CJ=c["M_CJ"],
              M2_behind_reaction_wave_frame=float(np.mean(M2s)) if M2s else None,
              M_exit_mass_avg=M_exit),
    fill_height_mm=float(np.mean(hs) * 1e3) if hs else None,
    fill_height_eq45_mm=float(op["mass_flux"] * R * c["T1"] / (c["p1"] * f0) * 1e3) if f0 > 0 else None,
    pressures_kPa=dict(z_mm=(z_paper * 1e3).tolist(), sim=(p_sim / 1e3).tolist(),
                       paper=(p_paper / 1e3).tolist(), ratio_65pct_to_head=float(p65 / prof[0])),
    mass=dict(mdot_in_gps=mdot_in * 1e3, mdot_out_gps=mdot_out * 1e3,
              imbalance_pct=100 * (mdot_out / mdot_in - 1), target_gps=op["mdot_target_gps"]),
    thrust=dict(F_exit_N=F_exit, F_bottom_N=F_bot, mismatch_pct=100 * (F_exit / F_bot - 1),
                Isp_s=Isp),
    roll_stability=dict(torque_on_engine_Nm=tau_eng, torque_to_thrust_m=tau_eng / F_exit,
                        torque_fluctuation_rel=tau_fluct, exit_swirl_velocity=u_exit,
                        swirl_power_fraction=swirl_power_frac, mundt_eq47_estimate=0.09,
                        roll_accel_per_unit_inertia=f"{abs(tau_eng):.3g} rad/s^2 per (kg m^2)",
                        spin_after_1s_rev_s={f"I={I} kg m^2": abs(tau_eng) / I / (2 * math.pi)
                                             for I in (0.005, 0.01, 0.05)}),
    floor_hits=meta["floor_hits"], wall_s=meta["wall_s"],
)
json.dump(res, open(f"{HERE}/{run}_results.json", "w"), indent=2, default=float)

# ---------------- summary table (D42) ----------------
ws, rs = res["wave_stability"], res["roll_stability"]
L_ = [f"# Results: {run}", "",
      f"Grid {res['grid']['dx_mm']:.2f} mm ({meta['nx']}×{meta['ny']}), L½ = {res['chemistry']['L_half_mm']:.2f} mm, "
      f"E_a/RT₁ = {res['chemistry']['Ea_over_RT1']}, averaged over t = {t0*1e3:.2f}–{t[-1]*1e3:.2f} ms.", "",
      "## 1. Wave stability (Mundt's definition)", "",
      "| Quantity | Simulation | Paper (Run 937, Table 3-2) |", "|---|---|---|",
      f"| Mode | **{ws['mode']}** | 2-wave, no counter wave |",
      f"| Wave count N, direction | {N}, {direction} | 2 |",
      f"| Passing frequency f | {f0/1e3:.2f} kHz | 15.84 kHz |",
      f"| Wave speed (outer-circumference convention) | {D_mundt:.0f} m/s | 1893 m/s |",
      f"| D / D_CJ | {D_sim/c['D_CJ']:.3f} | 0.766 |",
      f"| Counter-wave power ratio | {cw_ratio*100:.1f}% (weak < 58% ≤ strong) | none |",
      f"| Steady across 3 sub-windows | {steady} {subs} | steady (Fig. 3.7) |",
      f"| Fill height | {res['fill_height_mm']:.2f} mm | Eq. 4.5: {res['fill_height_eq45_mm']:.2f} mm (sim f); avg 3.25 mm (§4.3) |",
      "", "## 2. Roll stability (torque from exhaust swirl)", "",
      "| Quantity | Value | Reference |", "|---|---|---|",
      f"| Torque on engine about axis | {tau_eng:+.3f} N·m | sign opposite to exhaust swirl |",
      f"| Torque / thrust | {tau_eng/F_exit*1e3:+.2f} mm | Sawada et al. 2022: 0.149 N·m / 48.1 N ≈ 3.1 mm |",
      f"| Torque fluctuation (std/mean) | {tau_fluct:.2f} | |",
      f"| Mass-avg exit swirl velocity | {u_exit:+.1f} m/s | |",
      f"| Swirl power / heat release power | {swirl_power_frac*100:.1f}% | Mundt Eq. 4.7, Fig. 4.28: ~9% |",
      f"| Roll acceleration | {abs(tau_eng):.3g} rad/s² per kg·m² of roll inertia | divide by your rocket's I |",
      "", "## 3. Performance and flow", "",
      "| Quantity | Simulation | Paper |", "|---|---|---|",
      f"| ṁ in / out | {mdot_in*1e3:.1f} / {mdot_out*1e3:.1f} g/s ({res['mass']['imbalance_pct']:+.1f}%) | 268.65 g/s |",
      f"| Thrust (exit plane) | {F_exit:.1f} N | not measured (p. 22) |",
      f"| Thrust (injector-face cross-check) | {F_bot:.1f} N ({res['thrust']['mismatch_pct']:+.1f}%) | |",
      f"| I_sp | {Isp:.1f} s | |",
      f"| M₁ (wave frame, fresh gas) | {res['mach']['M1_wave_frame'] or float('nan'):.2f} | M_CJ = {c['M_CJ']:.2f} (calibrated) |",
      f"| M₂ behind reaction (wave frame) | {res['mach']['M2_behind_reaction_wave_frame'] or float('nan'):.2f} | 1 for CJ |",
      f"| Exit Mach (mass-avg) | {M_exit:.2f} | |",
      "", "## 4. Axial pressure (time- and circumference-averaged)", "",
      "| z [mm] | Simulation [kPa] | Paper [kPa] | Ratio |", "|---|---|---|---|"]
for z_, a_, b_ in zip(z_paper * 1e3, p_sim / 1e3, p_paper / 1e3):
    L_.append(f"| {z_:.1f} | {a_:.0f} | {b_:.0f} | {a_/b_:.2f} |")
L_ += ["", f"p(65% L) / p(head) = {p65/prof[0]:.2f} (Mundt §4.3: ≈ 0.73)", "",
       f"Density/pressure floor hits: {meta['floor_hits']}. Wall-clock: {meta['wall_s']:.0f} s."]
open(f"{HERE}/{run}_summary.md", "w").write("\n".join(L_) + "\n")

# ---------------- plots (Figs. 3.5 / 3.6 / 3.7 analogues) ----------------
fig, ax = plt.subplots(1, 3, figsize=(15, 4.2))
ax[0].imshow(ptx.T / 1e6, aspect="auto", origin="lower", cmap="inferno",
             extent=[tu[0] * 1e3, tu[-1] * 1e3, 0, 360], vmax=np.percentile(ptx, 99.5) / 1e6)
ax[0].set_xlabel("t [ms]"); ax[0].set_ylabel("angle [deg]"); ax[0].set_title("x–t: pressure at injector face (cf. Fig. 3.5)")
ks = np.fft.fftshift(kk); fs = np.fft.fftshift(fr)
Psh = np.fft.fftshift(P)
selk = np.abs(ks) <= 6; self_ = (fs > 0) & (fs < 60e3)
ax[1].imshow(np.log10(Psh[np.ix_(self_, selk)] + 1e-30).T, aspect="auto", origin="lower",
             extent=[fs[self_][0] / 1e3, fs[self_][-1] / 1e3, -6.5, 6.5], cmap="viridis")
ax[1].set_xlabel("f [kHz]"); ax[1].set_ylabel("wave number k (−: +x travel)")
ax[1].set_title(f"2D FFT (cf. Fig. 3.6): N={N}, f={f0/1e3:.2f} kHz")
ax[2].plot(t * 1e3, -d["tau_gas"], lw=.6, label="torque on engine [N·m]")
ax2 = ax[2].twinx(); ax2.plot(t * 1e3, d["F_exit"], c="C1", lw=.6, label="thrust [N]")
ax[2].axvline(t0 * 1e3, ls=":", c="k"); ax[2].set_xlabel("t [ms]"); ax[2].set_ylabel("torque [N·m]")
ax2.set_ylabel("thrust [N]"); ax[2].set_title("Torque and thrust history (avg window right of dotted line)")
fig.tight_layout(); fig.savefig(f"{HERE}/{run}_waves.png", dpi=110)
print("\n".join(L_))
