"""Calibrate the single-gamma, one-step chemistry to Mundt's numbers (plan D6-D15).

Outputs calib.json (gamma, R, Q, q, k, Ea, reference states) and znd_profile.png
(a Fig. 1.7-style plot of the calibrated ZND wave).
"""
import json, math, sys
import numpy as np
import yaml
from scipy.integrate import quad
from scipy.optimize import brentq

HERE = sys.path[0]
cfg = yaml.safe_load(open(f"{HERE}/config.yaml"))
op, ch, geo = cfg["operating_point"], cfg["chemistry"], cfg["geometry"]
# optional overrides: python calibrate.py [L_half_mm] [Ea_over_RT1] [out_name]
if len(sys.argv) > 1: ch["L_half_mm"] = float(sys.argv[1])
if len(sys.argv) > 2: ch["Ea_over_RT1"] = float(sys.argv[2])
OUT = sys.argv[3] if len(sys.argv) > 3 else "calib"

# D6: mixture gas constant at phi (CH4:O2 = phi:2 by moles)
phi = op["phi"]
x_ch4 = phi / (phi + 2.0)
MW = x_ch4 * 16.043 + (1 - x_ch4) * 31.999
R = 8314.46 / MW
T1 = op["T_plenum_K"]

# D11: Mundt Eq. 4.1 fill pressure (kPa), inputs mass flux and phi
m = op["mass_flux"]
p1_kPa = (-531.2 + 2.965 * m + 526.6 * phi + 0.0009336 * m * m
          - 1.418 * m * phi - 54.73 * phi * phi)
p1 = p1_kPa * 1e3


def dcj(g, q):
    """CJ speed from Eq. 1.7 (upper root) for the single-gamma model."""
    cp = g * R / (g - 1)
    Q = q / (cp * T1)
    x = 1 + (g + 1) * Q
    M2 = x + math.sqrt(x * x - 1)
    return math.sqrt(M2) * math.sqrt(g * R * T1)


# D9: gamma such that both D_CJ (Table 3-2) and q (Fig. 4.4) are matched
q = op["q_MJkg"] * 1e6
g = brentq(lambda gg: dcj(gg, q) - op["D_CJ"], 1.05, 1.6)
cp = g * R / (g - 1)
Q = q / (cp * T1)
a1 = math.sqrt(g * R * T1)
M1 = op["D_CJ"] / a1


def heat_mach(M1, Qx, g):
    """Subsonic (strong-branch) M2 from Eq. 1.6 for heat Qx; ZND path after the shock."""
    f = lambda M2: ((M2 / M1) ** 2 * ((1 + g * M1 * M1) / (1 + g * M2 * M2)) ** 2
                    * (1 + 0.5 * (g - 1) * M2 * M2) - (1 + 0.5 * (g - 1) * M1 * M1) - Qx)
    # f is increasing in M2 on (0,1]; at Qx = Q (CJ) the root is exactly 1
    if f(1.0) <= 0:
        return 1.0
    return brentq(f, 1e-6, 1.0)


def state(xi):
    """T/T1, p/p1, M and velocity (shock frame) at reaction progress xi (Eqs. 1.6, 1.9, 1.10)."""
    M2 = heat_mach(M1, xi * Q, g)
    T = (M2 / M1) ** 2 * ((1 + g * M1 ** 2) / (1 + g * M2 ** 2)) ** 2
    p = (1 + g * M1 ** 2) / (1 + g * M2 ** 2)
    u = M2 * math.sqrt(g * R * T * T1)
    return T, p, M2, u


Ea = ch["Ea_over_RT1"] * R * T1  # J/kg (rate uses Ea/(R T))


def dx_dxi(xi, k):
    T, p, M, u = state(xi)
    return u / (k * (1 - xi) * math.exp(-Ea / (R * T * T1)))


# D14: k so that the half-reaction length is L_half
L1 = quad(dx_dxi, 0.0, 0.5, args=(1.0,), limit=200)[0]
k = L1 / (ch["L_half_mm"] * 1e-3)
L_check = quad(dx_dxi, 0.0, 0.5, args=(k,), limit=200)[0]

Tvn, pvn, Mvn, uvn = state(0.0)
Tcj = ((1 + g * M1 ** 2) / ((1 + g) * M1)) ** 2
pcj = (1 + g * M1 ** 2) / (1 + g)
lam_real = 0.8e-3  # Fig. 4.2, ~350-380 kPa, phi~1.18 (read off the plot)

out = dict(Ea_over_RT1=ch["Ea_over_RT1"], R=R, MW=MW, gamma=g, cp=cp, Q=Q, q=q, T1=T1, p1=p1, a1=a1, M_CJ=M1,
           D_CJ=op["D_CJ"], k=k, Ea=Ea, L_half=L_check,
           VN=dict(p=pvn * p1, T=Tvn * T1, M=Mvn, u_shock_frame=uvn),
           CJ=dict(p=pcj * p1, T=Tcj * T1),
           lambda_real=lam_real, induction_real=lam_real / 29.0)
json.dump(out, open(f"{HERE}/{OUT}.json", "w"), indent=2)
print(json.dumps(out, indent=2))

# D15: Fig. 1.7-style profile for the calibrated model
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
xis = np.linspace(0, 0.999, 300)
S = np.array([state(x) for x in xis])
xs = np.array([0.0] + [quad(dx_dxi, 0, x, args=(k,), limit=200)[0] for x in xis[1:]])
fig, ax = plt.subplots(1, 4, figsize=(14, 3.4))
ax[0].plot(xis, S[:, 2]); ax[0].plot([0], [M1], "o"); ax[0].set_ylabel("M (shock frame)")
ax[1].plot(xis, S[:, 1] * p1 / 1e6); ax[1].plot([0], [p1 / 1e6], "ko"); ax[1].set_ylabel("p [MPa]")
ax[2].plot(xis, S[:, 0] * T1); ax[2].plot([0], [T1], "ko"); ax[2].set_ylabel("T [K]")
for a in ax[:3]:
    a.set_xlabel("ξ"); a.grid(alpha=.3)
ax[3].plot(xs * 1e3, xis); ax[3].axhline(0.5, ls=":", c="k")
ax[3].set_xlabel("distance behind shock [mm]"); ax[3].set_ylabel("ξ"); ax[3].grid(alpha=.3)
fig.suptitle(f"Calibrated ZND wave (γ={g:.3f}, Q={Q:.2f}, M_CJ={M1:.2f}, L½={L_check*1e3:.2f} mm) "
             "— compare Mundt Fig. 1.7")
fig.tight_layout()
fig.savefig(f"{HERE}/znd_profile_{OUT}.png" if OUT != "calib" else f"{HERE}/znd_profile.png", dpi=120)
