"""Checkpoint tests (plan Part 2, 0:25-0:55): Sod shock tube and 1D detonation tube."""
import json, sys, time
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from solver import Solver, REFLECT, TRANSMIT, WALL

HERE = sys.path[0]
c = json.load(open(f"{HERE}/calib.json"))

# --- Sod shock tube (no chemistry), gamma = 1.4, t = 0.2 ---
n = 400
s = Solver(n, 1, 1.0 / n, 1.0 / n, (1.4, 0.0, 1.0, 0.0, 1.0), (TRANSMIT, TRANSMIT, WALL, WALL))
x = (np.arange(n) + 0.5) / n
r = np.where(x < 0.5, 1.0, 0.125)[:, None]; p = np.where(x < 0.5, 1.0, 0.1)[:, None]
s.set_prim(r, 0 * r, 0 * r, p, 0 * r)
s.p_min = 1e-9  # non-dimensional test: the default 1 Pa floor would clip p = 0.1
while s.t < 0.2:
    s.step()
W = s.prim()
# exact Sod values in the star region: p* = 0.30313, u* = 0.92745, shock at x = 0.8504
i_star = int(0.75 * n)
sod = dict(p_star=float(W[3, i_star, 0]), u_star=float(W[1, i_star, 0]),
           shock_x=float(x[np.where(W[0, :, 0] > 0.2)[0].max()]))
print("Sod:", sod, "(exact p*=0.3031, u*=0.9274, shock x=0.850)")

# --- 1D detonation tube with the calibrated chemistry ---
g, q, R, k, Ea = c["gamma"], c["q"], c["R"], c["k"], c["Ea"]
p1, T1 = c["p1"], c["T1"]
dx = 0.25e-3
n = 1000
s = Solver(n, 1, dx, dx, (g, q, R, k, Ea), (REFLECT, TRANSMIT, WALL, WALL))
x = (np.arange(n) + 0.5) * dx
r = np.full((n, 1), p1 / (R * T1)); p = np.full((n, 1), p1); xi = np.zeros((n, 1))
# Ignition: 10 mm at 2x the CJ pressure. A 5 mm patch at the CJ state (plan D28) was below the
# critical initiation energy: the shock decoupled from the reaction and decayed to ~870 m/s.
hot = x < 10e-3
p[hot] = 2 * c["CJ"]["p"]; r[hot] = 2 * c["CJ"]["p"] / (R * c["CJ"]["T"]); xi[hot] = 1.0
s.set_prim(r, 0 * r, 0 * r, p, xi)
ts, xs, pk = [], [], []
t0 = time.time()
while s.t < 95e-6:
    s.step()
    W = s.prim()
    idx = np.where(W[3, :, 0] > 2 * p1)[0]
    if len(idx):
        ts.append(s.t); xs.append(x[idx.max()]); pk.append(W[3, :, 0].max())
ts, xs, pk = map(np.array, (ts, xs, pk))
sel = ts > 40e-6
D = np.polyfit(ts[sel], xs[sel], 1)[0]
det = dict(D=float(D), D_CJ=c["D_CJ"], err_pct=float(100 * (D / c["D_CJ"] - 1)),
           p_peak_MPa=float(pk[sel].mean() / 1e6), p_VN_MPa=c["VN"]["p"] / 1e6,
           wall_s=time.time() - t0)
print("Detonation tube:", det)
json.dump(dict(sod=sod, detonation=det), open(f"{HERE}/test_1d.json", "w"), indent=2)

W = s.prim()
fig, ax = plt.subplots(1, 2, figsize=(11, 3.3))
ax[0].plot(x * 1e3, W[3, :, 0] / 1e6); ax[0].set_xlabel("x [mm]"); ax[0].set_ylabel("p [MPa]")
ax[0].axhline(c["VN"]["p"] / 1e6, ls=":", c="r", label="von Neumann (ZND)")
ax[0].axhline(c["CJ"]["p"] / 1e6, ls="--", c="g", label="CJ (ZND)"); ax[0].legend()
ax[1].plot(ts * 1e6, xs * 1e3); ax[1].set_xlabel("t [µs]"); ax[1].set_ylabel("shock position [mm]")
ax[1].set_title(f"D = {D:.0f} m/s vs D_CJ = {c['D_CJ']:.0f} m/s ({det['err_pct']:+.1f}%)")
for a in ax: a.grid(alpha=.3)
fig.tight_layout(); fig.savefig(f"{HERE}/test_1d.png", dpi=120)
