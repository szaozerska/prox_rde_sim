# rde_sim starter: status (2026-10-21)

Partial prototype written before revision 3 of first_sim_plan.md. Reuse the structure; don't trust it as final.

| File | State |
|---|---|
| calibrate.py | Works. One-step chemistry only. Computes γ, Q, CJ/VN states, k for a target half-reaction length, ZND plot. Needs: two-step constants (Appendix A.3) and the GRI-Mech T_a fit (A.2) |
| solver.py | Works for 5 variables (one-step). MUSCL-minmod + HLL + SSP-RK2, periodic/reflective/transmissive ghosts, injector face flux (no backflow), floors. Needs: 6th variable λ (two-step), friction/heat-loss sources, faces computed once (currently computed twice), zero-gradient top boundary (currently imposes back pressure when subsonic) |
| test_1d.py | Passes: Sod exact; 1D detonation 2490 m/s vs 2471 (+0.8%), peak 20.4 vs 21.5 MPa (one-step, Ea/RT1 = 20, L½ = 1 mm, dx = 0.25 mm, ignition 10 mm at 2×p_CJ) |
| run.py | Runs the 2D unrolled 76-FI-5 case. Wave dies by about 90 µs (fill layer burns at the injector face; see Appendix D). Needs: everything in the plan's D2b, D26–D31 and Part 4 (live view, checkpoints) |
| analyze.py | Draft (x–t, 2D FFT, classification, thrust, torque). Untested on a working run. Needs: arrival-time f, camera-signal counter-wave ratio, friction-based torque, Appendix C definitions |
| config.yaml | Old single-file config; split per D2b |
