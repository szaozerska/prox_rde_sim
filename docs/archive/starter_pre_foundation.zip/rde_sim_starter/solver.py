"""2D reacting Euler solver for the unrolled RDE (plan D16-D24, D26).

Finite volume on a uniform grid, MUSCL-minmod on primitives, HLL flux, SSP-RK2,
one-step Arrhenius reaction (Mundt Eq. 1.11) with chemical energy stored in E.

Arrays: U[var, i, j] with NG ghost cells. Variables: rho, rho*u, rho*v, E, rho*xi.
x (index i) = around the circumference, y (index j) = along the axis.
"""
import numpy as np
from numba import njit, prange

NG = 2
# boundary codes
PERIODIC, REFLECT, TRANSMIT = 0, 1, 2          # x-ends (left / right)
WALL, INJECTOR, OUTFLOW = 0, 1, 2              # y-ends (bottom / top)


@njit(cache=True, inline="always")
def minmod(a, b):
    if a * b <= 0.0:
        return 0.0
    return a if abs(a) < abs(b) else b


@njit(cache=True, parallel=True)
def cons_to_prim(U, W, g, q):
    nx, ny = U.shape[1], U.shape[2]
    for i in prange(nx):
        for j in range(ny):
            r = U[0, i, j]
            u = U[1, i, j] / r
            v = U[2, i, j] / r
            xi = min(max(U[4, i, j] / r, 0.0), 1.0)
            p = (g - 1.0) * (U[3, i, j] - 0.5 * r * (u * u + v * v) - r * q * (1.0 - xi))
            W[0, i, j] = r; W[1, i, j] = u; W[2, i, j] = v; W[3, i, j] = p; W[4, i, j] = xi


@njit(cache=True)
def prim_to_cons_cell(r, u, v, p, xi, g, q, out):
    out[0] = r; out[1] = r * u; out[2] = r * v
    out[3] = p / (g - 1.0) + 0.5 * r * (u * u + v * v) + r * q * (1.0 - xi)
    out[4] = r * xi


@njit(cache=True)
def fill_ghosts(W, bcl, bcr, bcb, bct, p_back, g):
    """Ghost cells on primitives. The injector face is handled as a flux, but its ghosts
    get a zero-gradient copy so the MUSCL slopes next to it are defined."""
    nxg, nyg = W.shape[1], W.shape[2]
    nx, ny = nxg - 2 * NG, nyg - 2 * NG
    for j in range(nyg):
        for k in range(NG):
            for v in range(5):
                if bcl == PERIODIC:
                    W[v, k, j] = W[v, nx + k, j]
                    W[v, nx + NG + k, j] = W[v, NG + k, j]
                else:
                    W[v, NG - 1 - k, j] = W[v, NG + k, j]          # mirror / copy (left)
                    W[v, nx + NG + k, j] = W[v, nx + NG - 1 - k, j] if bcr == REFLECT else W[v, nx + NG - 1, j]
            if bcl == REFLECT:
                W[1, NG - 1 - k, j] = -W[1, NG + k, j]
            if bcr == REFLECT and bcl != PERIODIC:
                W[1, nx + NG + k, j] = -W[1, nx + NG - 1 - k, j]
    for i in range(nxg):
        for k in range(NG):
            for v in range(5):
                W[v, i, NG - 1 - k] = W[v, i, NG + k] if bcb == WALL else W[v, i, NG]
                W[v, i, ny + NG + k] = W[v, i, ny + NG - 1 - k] if bct == WALL else W[v, i, ny + NG - 1]
            if bcb == WALL:
                W[2, i, NG - 1 - k] = -W[2, i, NG + k]
            if bct == WALL:
                W[2, i, ny + NG + k] = -W[2, i, ny + NG - 1 - k]
            elif bct == OUTFLOW:
                # D26: subsonic outflow -> impose back pressure; supersonic -> extrapolate
                r = W[0, i, ny + NG - 1]; vv = W[2, i, ny + NG - 1]; pp = W[3, i, ny + NG - 1]
                a = np.sqrt(g * max(pp, 1e-9) / r)
                if vv < a:
                    W[3, i, ny + NG + k] = p_back


@njit(cache=True, inline="always")
def hll(rL, uL, vL, pL, xL, rR, uR, vR, pR, xR, nxd, g, q, F):
    """HLL flux normal to a face. nxd=1: x-face (normal velocity u), nxd=0: y-face (v)."""
    unL = uL if nxd == 1 else vL
    unR = uR if nxd == 1 else vR
    aL = np.sqrt(g * pL / rL); aR = np.sqrt(g * pR / rR)
    EL = pL / (g - 1.0) + 0.5 * rL * (uL * uL + vL * vL) + rL * q * (1.0 - xL)
    ER = pR / (g - 1.0) + 0.5 * rR * (uR * uR + vR * vR) + rR * q * (1.0 - xR)
    sL = min(unL - aL, unR - aR)
    sR = max(unL + aL, unR + aR)
    # physical fluxes
    fL0 = rL * unL; fR0 = rR * unR
    fL1 = rL * uL * unL; fR1 = rR * uR * unR
    fL2 = rL * vL * unL; fR2 = rR * vR * unR
    if nxd == 1:
        fL1 += pL; fR1 += pR
    else:
        fL2 += pL; fR2 += pR
    fL3 = (EL + pL) * unL; fR3 = (ER + pR) * unR
    fL4 = rL * xL * unL; fR4 = rR * xR * unR
    if sL >= 0.0:
        F[0] = fL0; F[1] = fL1; F[2] = fL2; F[3] = fL3; F[4] = fL4
    elif sR <= 0.0:
        F[0] = fR0; F[1] = fR1; F[2] = fR2; F[3] = fR3; F[4] = fR4
    else:
        inv = 1.0 / (sR - sL)
        F[0] = (sR * fL0 - sL * fR0 + sL * sR * (rR - rL)) * inv
        F[1] = (sR * fL1 - sL * fR1 + sL * sR * (rR * uR - rL * uL)) * inv
        F[2] = (sR * fL2 - sL * fR2 + sL * sR * (rR * vR - rL * vL)) * inv
        F[3] = (sR * fL3 - sL * fR3 + sL * sR * (ER - EL)) * inv
        F[4] = (sR * fL4 - sL * fR4 + sL * sR * (rR * xR - rL * xL)) * inv


@njit(cache=True)
def injector_flux(pw, p0, T0, R, g, q, sigma, Cd, F):
    """D24: micro-nozzle injector face flux (no backflow). Returns flux into the domain (+y)."""
    pcr = p0 * (2.0 / (g + 1.0)) ** (g / (g - 1.0))
    cp = g * R / (g - 1.0)
    if pw >= p0:                                     # blocked (region F, Fig. 1.10)
        F[0] = 0.0; F[1] = 0.0; F[2] = pw; F[3] = 0.0; F[4] = 0.0
        return 0.0
    if pw < pcr:                                     # choked (Eq. 2.1 form)
        G = Cd * p0 * np.sqrt(g / (R * T0)) * (2.0 / (g + 1.0)) ** ((g + 1.0) / (2.0 * (g - 1.0)))
    else:                                            # subsonic orifice
        rr = pw / p0
        rho0 = p0 / (R * T0)
        G = Cd * np.sqrt(2.0 * g / (g - 1.0) * p0 * rho0 * (rr ** (2.0 / g) - rr ** ((g + 1.0) / g)))
    uj = np.sqrt(max(2.0 * cp * T0 * (1.0 - (pw / p0) ** ((g - 1.0) / g)), 0.0))
    m = sigma * G
    F[0] = m; F[1] = 0.0; F[2] = m * uj + pw; F[3] = m * (cp * T0 + q); F[4] = 0.0
    return m


@njit(cache=True, parallel=True)
def rhs(W, dUdt, Fb, dx, dy, g, q, R, k, Ea, bcb, inj):
    """Spatial operator + reaction source. inj = (p0, T0, sigma, Cd). Fb stores the bottom
    face flux per column (for diagnostics)."""
    nxg, nyg = W.shape[1], W.shape[2]
    nx, ny = nxg - 2 * NG, nyg - 2 * NG
    for i in prange(NG, nx + NG):
        F = np.empty(5); Fm = np.empty(5); Gp = np.empty(5); Gm = np.empty(5)
        L = np.empty(5); Rr = np.empty(5)
        for j in range(NG, ny + NG):
            # x-faces i-1/2 and i+1/2
            for side in range(2):
                ia = i - 1 + side          # left cell of the face
                for v in range(5):
                    L[v] = W[v, ia, j] + 0.5 * minmod(W[v, ia, j] - W[v, ia - 1, j], W[v, ia + 1, j] - W[v, ia, j])
                    Rr[v] = W[v, ia + 1, j] - 0.5 * minmod(W[v, ia + 1, j] - W[v, ia, j], W[v, ia + 2, j] - W[v, ia + 1, j])
                if side == 0:
                    hll(L[0], L[1], L[2], L[3], L[4], Rr[0], Rr[1], Rr[2], Rr[3], Rr[4], 1, g, q, Fm)
                else:
                    hll(L[0], L[1], L[2], L[3], L[4], Rr[0], Rr[1], Rr[2], Rr[3], Rr[4], 1, g, q, F)
            # y-faces j-1/2 and j+1/2
            for side in range(2):
                ja = j - 1 + side
                if side == 0 and j == NG and bcb == INJECTOR:
                    Fb[i - NG] = injector_flux(W[3, i, NG], inj[0], inj[1], R, g, q, inj[2], inj[3], Gm)
                    continue
                for v in range(5):
                    L[v] = W[v, i, ja] + 0.5 * minmod(W[v, i, ja] - W[v, i, ja - 1], W[v, i, ja + 1] - W[v, i, ja])
                    Rr[v] = W[v, i, ja + 1] - 0.5 * minmod(W[v, i, ja + 1] - W[v, i, ja], W[v, i, ja + 2] - W[v, i, ja + 1])
                if side == 0:
                    hll(L[0], L[1], L[2], L[3], L[4], Rr[0], Rr[1], Rr[2], Rr[3], Rr[4], 0, g, q, Gm)
                else:
                    hll(L[0], L[1], L[2], L[3], L[4], Rr[0], Rr[1], Rr[2], Rr[3], Rr[4], 0, g, q, Gp)
            for v in range(5):
                dUdt[v, i, j] = -(F[v] - Fm[v]) / dx - (Gp[v] - Gm[v]) / dy
            # D12: one-step reaction source on rho*xi (Eq. 1.11)
            r = W[0, i, j]; xi = W[4, i, j]
            T = W[3, i, j] / (r * R)
            dUdt[4, i, j] += r * k * (1.0 - xi) * np.exp(-Ea / (R * T))


@njit(cache=True, parallel=True)
def max_speed(W, g):
    nxg, nyg = W.shape[1], W.shape[2]
    sx = np.zeros(nxg); sy = np.zeros(nxg)
    for i in prange(NG, nxg - NG):
        for j in range(NG, nyg - NG):
            a = np.sqrt(g * W[3, i, j] / W[0, i, j])
            sx[i] = max(sx[i], abs(W[1, i, j]) + a)
            sy[i] = max(sy[i], abs(W[2, i, j]) + a)
    return sx.max(), sy.max()


@njit(cache=True, parallel=True)
def floors(U, rho_min, p_min, g, q):
    """D21: density/pressure floors; returns how many cells were touched."""
    nxg, nyg = U.shape[1], U.shape[2]
    cnt = np.zeros(nxg, dtype=np.int64)
    for i in prange(NG, nxg - NG):
        for j in range(NG, nyg - NG):
            r = U[0, i, j]
            if r < rho_min:
                U[0, i, j] = rho_min; U[1, i, j] *= rho_min / r; U[2, i, j] *= rho_min / r
                U[4, i, j] *= rho_min / r; r = rho_min; cnt[i] += 1
            xi = min(max(U[4, i, j] / r, 0.0), 1.0)
            U[4, i, j] = r * xi
            ke = 0.5 * (U[1, i, j] ** 2 + U[2, i, j] ** 2) / r
            p = (g - 1.0) * (U[3, i, j] - ke - r * q * (1.0 - xi))
            if p < p_min:
                U[3, i, j] = p_min / (g - 1.0) + ke + r * q * (1.0 - xi); cnt[i] += 1
    return cnt.sum()


class Solver:
    def __init__(self, nx, ny, dx, dy, gas, bc, inj=(0.0, 300.0, 0.0, 1.0), p_back=1e5, cfl=0.4):
        self.nx, self.ny, self.dx, self.dy = nx, ny, dx, dy
        self.g, self.q, self.R, self.k, self.Ea = gas
        self.bc = bc                       # (left, right, bottom, top)
        self.inj = np.array(inj, dtype=np.float64)
        self.p_back, self.cfl = p_back, cfl
        shape = (5, nx + 2 * NG, ny + 2 * NG)
        self.U = np.zeros(shape); self.W = np.zeros(shape)
        self.k1 = np.zeros(shape); self.U1 = np.zeros(shape)
        self.Fb = np.zeros(nx)
        self.rho_min = 1e-6; self.p_min = 1.0
        self.floor_hits = 0
        self.t = 0.0

    def set_prim(self, r, u, v, p, xi):
        """Set the interior from primitive arrays of shape (nx, ny)."""
        s = slice(NG, -NG)
        g, q = self.g, self.q
        self.U[0, s, s] = r; self.U[1, s, s] = r * u; self.U[2, s, s] = r * v
        self.U[3, s, s] = p / (g - 1) + 0.5 * r * (u * u + v * v) + r * q * (1 - xi)
        self.U[4, s, s] = r * xi

    def _L(self, U, out):
        cons_to_prim(U, self.W, self.g, self.q)
        fill_ghosts(self.W, *self.bc, self.p_back, self.g)
        rhs(self.W, out, self.Fb, self.dx, self.dy, self.g, self.q, self.R, self.k, self.Ea,
            self.bc[2], self.inj)

    def step(self):
        cons_to_prim(self.U, self.W, self.g, self.q)
        fill_ghosts(self.W, *self.bc, self.p_back, self.g)
        sx, sy = max_speed(self.W, self.g)
        dt = self.cfl / (sx / self.dx + sy / self.dy)
        # SSP-RK2 (D20)
        self._L(self.U, self.k1)
        self.U1[:] = self.U + dt * self.k1
        self.floor_hits += floors(self.U1, self.rho_min, self.p_min, self.g, self.q)
        self._L(self.U1, self.k1)
        self.U[:] = 0.5 * self.U + 0.5 * (self.U1 + dt * self.k1)
        self.floor_hits += floors(self.U, self.rho_min, self.p_min, self.g, self.q)
        self.t += dt
        return dt

    def prim(self):
        cons_to_prim(self.U, self.W, self.g, self.q)
        return self.W[:, NG:-NG, NG:-NG]
